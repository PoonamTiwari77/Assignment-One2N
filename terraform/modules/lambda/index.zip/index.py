import json
import boto3
from botocore.exceptions import ClientError

# Initialize the S3 client
s3_client = boto3.client('s3')

def list_s3_objects(bucket_name, prefix=''):
    try:
        # List objects within the specified bucket and prefix
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
        
        # Prepare lists for directories and files
        directories = []
        files = []

        # Process directories
        if 'CommonPrefixes' in response:
            for common_prefix in response['CommonPrefixes']:
                dir_name = common_prefix['Prefix'].strip('/').split('/')[-1]
                directories.append(dir_name)

        # Process files
        if 'Contents' in response:
            for obj in response['Contents']:
                file_name = obj['Key'].split('/')[-1]
                if file_name:  # Only add non-empty names
                    files.append(file_name)
        
        return {
            'directories': directories,
            'files': files
        }
    except ClientError as e:
        # Print error and return None for error handling
        print(f"Error listing objects in bucket {bucket_name}: {e}")
        return None

def lambda_handler(event, context):
    # Extract bucket and path from event path parameters
    bucket_name = event['pathParameters']['bucket']
    path = event['pathParameters'].get('path', '')  # Default to empty string if no path is provided

    # Call the list_s3_objects function to retrieve contents
    result = list_s3_objects(bucket_name, prefix=path)

    if result is None:
        # Return a 404 error if the path does not exist or an error occurred
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Bucket or path not found'})
        }
    
    # Return the response with listed contents
    return {
        'statusCode': 200,
        'body': json.dumps({
            'content': result['directories'] + result['files']
        })
    }
